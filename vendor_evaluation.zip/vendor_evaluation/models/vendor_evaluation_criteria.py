# -*- coding: utf-8 -*-
from odoo import models, fields, api
from odoo.exceptions import ValidationError


class VendorEvaluationCriteria(models.Model):
    _name = 'vendor.evaluation.criteria'
    _description = 'Vendor Evaluation Criteria'

    name = fields.Char(
        string='Tên tiêu chí',
        required=True
    )

    code = fields.Selection([
        ('quality', 'Chất lượng'),
        ('price', 'Giá cả'),
        ('delivery', 'Đúng hạn')
    ], string='Loại tiêu chí', required=True)

    weight = fields.Float(
        string='Trọng số (%)',
        required=True,
        default=0
    )

    active = fields.Boolean(
        string='Kích hoạt',
        default=True
    )

    @api.constrains('weight')
    def _check_weight(self):
        for rec in self:
            if rec.weight < 0 or rec.weight > 100:
                raise ValidationError(
                    "Trọng số phải nằm trong khoảng từ 0 đến 100."
                )