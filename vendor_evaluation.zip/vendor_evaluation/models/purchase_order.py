# -*- coding: utf-8 -*-
from odoo import models, fields, api, _
from odoo.exceptions import ValidationError, UserError


class PurchaseOrder(models.Model):
    _inherit = 'purchase.order'

    partner_id = fields.Many2one(
        'res.partner',
        string='Nhà cung cấp',
        required=False,
        domain=[('supplier_rank', '>', 0)]
    )

    def action_rfq_send(self):
        for order in self:
            if not order.partner_id:
                raise ValidationError(
                    _("Vui lòng chọn nhà cung cấp trước khi gửi RFQ!")
                )

            if not order.order_line:
                raise ValidationError(
                    _("RFQ phải có ít nhất một sản phẩm!")
                )

        return super().action_rfq_send()

    def button_confirm(self):
        for order in self:
            if not order.partner_id:
                raise ValidationError(
                    _("Chưa chọn nhà cung cấp!")
                )

            if not order.order_line:
                raise ValidationError(
                    _("Đơn mua hàng phải có ít nhất một sản phẩm!")
                )

        return super().button_confirm()

    def button_cancel(self):
        for order in self:
            pickings = order.picking_ids

            has_received = any(
                p.state == 'done'
                for p in pickings
            )

            if has_received:
                raise UserError(
                    _("Không thể hủy đơn vì đã nhập kho.")
                )

        return super().button_cancel()


class PurchaseOrderLine(models.Model):
    _inherit = 'purchase.order.line'

    x_suggested_vendor_id = fields.Many2one(
        'res.partner',
        string='Nhà cung cấp đề xuất',
        domain=[('supplier_rank', '>', 0)]
    )

    x_vendor_score_display = fields.Float(
        related='x_suggested_vendor_id.x_vendor_rating',
        string='Điểm số',
        readonly=True
    )

    @api.onchange('x_suggested_vendor_id')
    def _onchange_x_suggested_vendor_id(self):
        if self.x_suggested_vendor_id:
            self.order_id.partner_id = self.x_suggested_vendor_id.id